# LLM-avusteinen kääntäjäsovellus (Python + Flask)

## Kuvaus
Tämä projekti on LLM-avusteinen kääntäjäsovellus, joka tukee seuraavia kieliä:
- Suomi
- Ruotsi
- Englanti
- Espanja

Kaikki kielet voidaan kääntää suomeksi ja suomesta muihin kieliin.  
Sovellus toimii web-sovelluksena Flaskilla ja hyödyntää OpenAI:n suurta kielimallia.

## Tavoite
- Demonstroida LLM:n käyttöä käytännön sovelluksessa
- Harjoitella Python-ohjelmointia ja API-integraatiota
- Toteuttaa helppo ja selkeä web-käyttöliittymä

## Teknologiat
- Python 3
- Flask
- OpenAI API

## Asennus ja käyttö

### Riippuvuudet
```bash
pip install flask openai
```

### API-avain
Aseta OpenAI API-avain ympäristömuuttujaan:

Linux / macOS:
```bash
export OPENAI_API_KEY="OMA_API_AVAIN"
```

Windows (PowerShell):
```powershell
setx OPENAI_API_KEY "OMA_API_AVAIN"
```

### Käynnistys
```bash
python app.py
```

Avaa selaimessa: `http://127.0.0.1:5000`

### Käyttö
1. Valitse käännössuunta: Suomi → vieras kieli tai Vieras kieli → Suomi  
2. Valitse kieli: ruotsi, englanti, espanja  
3. Syötä teksti  
4. Saat käännöksen selaimessa  

## Jatkokehitysideoita
- Lisää kieliä
- Käännöshistoria
- Docker-paketointi
- Ulkoasun parantaminen
