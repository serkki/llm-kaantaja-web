# Kurssipäiväkirja

## Opitut aiheet
Kurssin aikana opin hyödyntämään suurta kielimallia osana Python-ohjelmaa.
Tutustuin OpenAI API:n käyttöön ja toteutin LLM-avusteisen kääntäjän web-sovelluksena.

## Havainnot ja oivallukset
LLM soveltuu hyvin monikieliseen kääntämiseen ilman kielikohtaisia sääntöjä.
Rajaus suomi ↔ vieras kielet piti sovelluksen yksinkertaisena ja helposti laajennettavana.

## Ongelmat ja ratkaisut
API-avaimen käyttö vaati aluksi perehtymistä, mutta ongelma ratkesi
ympäristömuuttujien avulla. Käännössuunnat ja valikot suunniteltiin käyttäjäystävällisiksi.

## Itsearviointi
Harjoitustyö vastasi kurssin tavoitteita ja paransi ymmärrystäni
LLM-avusteisista sovelluksista. Web-versio tekee sovelluksesta käyttökelpoisen
suoraan selaimessa.
