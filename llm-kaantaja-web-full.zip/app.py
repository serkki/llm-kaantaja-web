from flask import Flask, render_template, request
from openai import OpenAI
import os

app = Flask(__name__)

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

KIELET = ["ruotsi", "englanti", "espanja"]

def kaanna(teksti, lahto, kohde):
    prompt = f"""
Käännä seuraava teksti kielestä {lahto} kieleen {kohde}.
Säilytä alkuperäinen merkitys ja tyyli.

Teksti:
{teksti}
"""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "Olet ammattimainen kääntäjä."},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message.content.strip()

@app.route("/", methods=["GET", "POST"])
def index():
    kaannos = ""
    if request.method == "POST":
        suunta = request.form["suunta"]
        kieli = request.form["kieli"]
        teksti = request.form["teksti"]

        if suunta == "fi_to":
            lahto = "suomi"
            kohde = kieli
        else:
            lahto = kieli
            kohde = "suomi"

        kaannos = kaanna(teksti, lahto, kohde)

    return render_template("index.html", kaannos=kaannos, kielet=KIELET)

if __name__ == "__main__":
    app.run(debug=True)
